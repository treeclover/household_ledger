package com.house.model.service;

public class HouseholdService {

}
