package com.house.model.dao;

public interface RMoneyDAO {

}
